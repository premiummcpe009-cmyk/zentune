/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.metrolist.shared.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import com.metrolist.shared.ui.components.LoadingIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.metrolist.shared.generated.resources.Res
import com.metrolist.shared.generated.resources.loading
import com.metrolist.shared.ui.LocalIsTv
import com.metrolist.shared.ui.haptics.rememberMetrolistHaptics
import com.metrolist.shared.ui.icons.MetrolistIcons
import com.metrolist.shared.ui.navigation.navigationPopupSource
import com.metrolist.shared.ui.theme.zentifyGlassButton
import com.metrolist.shared.ui.tv.tvFocusHighlight
import org.jetbrains.compose.resources.stringResource

fun vintageOnButtonColor(buttonColor: Color): Color = if (buttonColor.luminance() > 0.5f) Color.Black else Color.White

data class VintageClassicControlsText(
    val repeat: String,
    val previous: String,
    val play: String,
    val pause: String,
    val next: String,
    val like: String,
    val unlike: String,
    val shuffle: String = "",
)

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun VintageClassicControls(
    text: VintageClassicControlsText,
    isPlaying: Boolean,
    isLoading: Boolean,
    repeatMode: Int,
    isLiked: Boolean,
    onToggleRepeat: () -> Unit,
    onSkipPrevious: (() -> Unit)?,
    onTogglePlay: () -> Unit,
    onSkipNext: (() -> Unit)?,
    onToggleLike: () -> Unit,
    contentColor: Color,
    buttonColor: Color,
    onButtonColor: Color,
    modifier: Modifier = Modifier,
    showLoadingIndicator: Boolean = true,
    buttonSize: Dp = 72.dp,
    playPauseFocusRequester: FocusRequester? = null,
    isShuffleOn: Boolean = false,
    onToggleShuffle: (() -> Unit)? = null,
) {
    val haptics = rememberMetrolistHaptics()
    val iconColors =
        IconButtonDefaults.iconButtonColors(
            contentColor = contentColor,
            disabledContentColor = contentColor.copy(alpha = 0.38f),
        )
    val playInteraction = remember { MutableInteractionSource() }
    val playPressed by playInteraction.collectIsPressedAsState()
    val playScale by animateFloatAsState(
        targetValue = if (playPressed) 0.9f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 500f),
        label = "classicPlayScale",
    )

    val repeatSlot: @Composable () -> Unit = {
        IconButton(
            onClick = onToggleRepeat,
            colors = iconColors,
            modifier = Modifier.size(48.dp).tvFocusHighlight(CircleShape).alpha(if (repeatMode == 0) 0.5f else 1f),
            shapes = IconButtonDefaults.shapes(),
        ) {
            Icon(
                imageVector = if (repeatMode == 1) MetrolistIcons.Outlined.RepeatOne else MetrolistIcons.Outlined.Repeat,
                contentDescription = text.repeat,
                modifier = Modifier.size(26.dp),
            )
        }
    }

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier.fillMaxWidth(),
    ) {
        // Left edge: shuffle when the player offers it, otherwise repeat as before.
        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
            if (onToggleShuffle != null) {
                IconButton(
                    onClick = onToggleShuffle,
                    colors = iconColors,
                    modifier = Modifier.size(48.dp).tvFocusHighlight(CircleShape).alpha(if (isShuffleOn) 1f else 0.5f),
                    shapes = IconButtonDefaults.shapes(),
                ) {
                    Icon(
                        imageVector = MetrolistIcons.Outlined.Shuffle,
                        contentDescription = text.shuffle,
                        modifier = Modifier.size(26.dp),
                    )
                }
            } else {
                repeatSlot()
            }
        }

        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
            IconButton(
                onClick = { onSkipPrevious?.invoke() },
                enabled = onSkipPrevious != null,
                colors = iconColors,
                modifier = Modifier.size(56.dp).tvFocusHighlight(CircleShape),
                shapes = IconButtonDefaults.shapes(),
            ) {
                Icon(
                    imageVector = ZentifyIcons.FastRewind,
                    contentDescription = text.previous,
                    modifier = Modifier.size(38.dp),
                )
            }
        }

        // Play and pause are just the glyph, with no container behind it.
        val playPauseDescription = if (isPlaying) text.pause else text.play
        Box(
            contentAlignment = Alignment.Center,
            modifier =
                Modifier
                    .size(buttonSize)
                    .scale(playScale)
                    .clip(CircleShape)
                    .tvFocusHighlight(CircleShape, color = contentColor)
                    .then(
                        if (playPauseFocusRequester != null) Modifier.focusRequester(playPauseFocusRequester) else Modifier,
                    ).semantics { contentDescription = playPauseDescription }
                    .clickable(
                        interactionSource = playInteraction,
                        indication = null,
                        role = Role.Button,
                        onClick = {
                            haptics.toggle(!isPlaying)
                            onTogglePlay()
                        },
                    ),
        ) {
            if (isLoading && showLoadingIndicator) {
                val loadingText = stringResource(Res.string.loading)
                LoadingIndicator(
                    modifier = Modifier.size(36.dp).semantics { contentDescription = loadingText },
                    color = contentColor,
                )
            } else {
                Icon(
                    imageVector = if (isPlaying) MetrolistIcons.Rounded.Pause else MetrolistIcons.Rounded.PlayArrow,
                    contentDescription = null,
                    tint = contentColor,
                    modifier = Modifier.size(buttonSize * 0.8f),
                )
            }
        }

        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
            IconButton(
                onClick = { onSkipNext?.invoke() },
                enabled = onSkipNext != null,
                colors = iconColors,
                modifier = Modifier.size(56.dp).tvFocusHighlight(CircleShape),
                shapes = IconButtonDefaults.shapes(),
            ) {
                Icon(
                    imageVector = ZentifyIcons.FastForward,
                    contentDescription = text.next,
                    modifier = Modifier.size(38.dp),
                )
            }
        }

        // Right edge: repeat after shuffle, otherwise the like button as before.
        Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
            if (onToggleShuffle != null) {
                repeatSlot()
            } else {
                IconButton(
                    onClick = onToggleLike,
                    colors =
                        IconButtonDefaults.iconButtonColors(
                            contentColor = if (isLiked) MaterialTheme.colorScheme.error else contentColor,
                        ),
                    modifier = Modifier.size(48.dp).tvFocusHighlight(CircleShape),
                    shapes = IconButtonDefaults.shapes(),
                ) {
                    Icon(
                        imageVector = if (isLiked) MetrolistIcons.Rounded.Favorite else MetrolistIcons.Rounded.FavoriteBorder,
                        contentDescription = if (isLiked) text.unlike else text.like,
                        modifier = Modifier.size(24.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun VintageClassicActionButtons(
    isLyricsVisible: Boolean,
    isLyricsExpanded: Boolean,
    shareDescription: String,
    expandDescription: String,
    collapseDescription: String,
    moreDescription: String,
    moreLyricsDescription: String,
    onToggleLyricsExpanded: () -> Unit,
    onShowLyricsMenu: () -> Unit,
    onShareClick: () -> Unit,
    onShowPlayerMenu: () -> Unit,
    buttonColor: Color,
    onButtonColor: Color,
    modifier: Modifier = Modifier,
    showExpandButton: Boolean = true,
    isLiked: Boolean = false,
    likeDescription: String = "",
    unlikeDescription: String = "",
    onLikeClick: (() -> Unit)? = null,
) {
    val isTv = LocalIsTv.current
    Row(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier,
    ) {
        AnimatedContent(targetState = isLyricsVisible, label = "VintageFirstAction") { showLyrics ->
            if (showLyrics) {
                if (showExpandButton) {
                    VintageCircleButton(
                        icon = if (isLyricsExpanded) MetrolistIcons.Default.FullscreenExit else MetrolistIcons.Default.Fullscreen,
                        description = if (isLyricsExpanded) collapseDescription else expandDescription,
                        onClick = onToggleLyricsExpanded,
                        buttonColor = buttonColor,
                        onButtonColor = onButtonColor,
                    )
                }
            } else if (onLikeClick != null) {
                VintageCircleButton(
                    icon = if (isLiked) MetrolistIcons.Rounded.Favorite else MetrolistIcons.Outlined.FavoriteBorder,
                    description = if (isLiked) unlikeDescription else likeDescription,
                    onClick = onLikeClick,
                    buttonColor = buttonColor,
                    onButtonColor = onButtonColor,
                    tint = if (isLiked) MaterialTheme.colorScheme.error else buttonColor,
                )
            } else if (!isTv) {
                VintageCircleButton(
                    icon = MetrolistIcons.Default.Share,
                    description = shareDescription,
                    onClick = onShareClick,
                    buttonColor = buttonColor,
                    onButtonColor = onButtonColor,
                )
            }
        }

        AnimatedContent(targetState = isLyricsVisible, label = "VintageSecondAction") { showLyrics ->
            VintageCircleButton(
                icon = if (showLyrics) MetrolistIcons.Default.MoreHoriz else MetrolistIcons.Outlined.MoreVert,
                description = if (showLyrics) moreLyricsDescription else moreDescription,
                onClick = if (showLyrics) onShowLyricsMenu else onShowPlayerMenu,
                buttonColor = buttonColor,
                onButtonColor = onButtonColor,
            )
        }
    }
}

/** A round glass button: a translucent disc with a thin outline, icon in the player's text colour. */
@Suppress("UNUSED_PARAMETER")
@Composable
private fun VintageCircleButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    buttonColor: Color,
    onButtonColor: Color,
    tint: Color = buttonColor,
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier =
            Modifier
                .size(44.dp)
                .navigationPopupSource()
                .zentifyGlassButton(CircleShape, buttonColor, bodyAlpha = 0.16f)
                .clip(CircleShape)
                .tvFocusHighlight(CircleShape, color = buttonColor)
                .semantics { contentDescription = description }
                .navigationPopupSource()
                .clickable(role = Role.Button, onClick = onClick),
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = tint,
            modifier = Modifier.size(22.dp),
        )
    }
}

@Composable
fun VintageClassicBottomBar(
    queueText: String,
    sleepTimerText: String,
    lyricsText: String,
    sleepTimerRemaining: String?,
    isSleepTimerEnabled: Boolean,
    onQueueClick: () -> Unit,
    onSleepTimerClick: (() -> Unit)?,
    sleepTimerDescription: String,
    onLyricsClick: () -> Unit,
    contentColor: Color,
    modifier: Modifier = Modifier,
    horizontalPadding: Dp = 30.dp,
    verticalPadding: Dp = 12.dp,
    onShareClick: (() -> Unit)? = null,
    shareText: String = "",
) {
    val isTv = LocalIsTv.current
    val sleepTimerActive = isSleepTimerEnabled && sleepTimerRemaining != null

    // Plain outline icons on one row: lyrics, queue, share and the sleep timer.
    Row(
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .fillMaxWidth()
                .padding(horizontal = horizontalPadding, vertical = verticalPadding),
    ) {
        VintageBottomBarItem(
            icon = MetrolistIcons.Outlined.Lyrics,
            description = lyricsText,
            contentColor = contentColor,
            onClick = onLyricsClick,
        )
        VintageBottomBarItem(
            icon = MetrolistIcons.AutoMirrored.Filled.QueueMusic,
            description = queueText,
            contentColor = contentColor,
            onClick = onQueueClick,
        )
        if (onShareClick != null && !isTv) {
            VintageBottomBarItem(
                icon = MetrolistIcons.Outlined.Share,
                description = shareText,
                contentColor = contentColor,
                onClick = onShareClick,
            )
        }
        if (onSleepTimerClick != null) {
            VintageBottomBarItem(
                icon = MetrolistIcons.Outlined.Bedtime,
                description = sleepTimerDescription.ifEmpty { sleepTimerText },
                contentColor = contentColor,
                onClick = onSleepTimerClick,
                label = sleepTimerRemaining.takeIf { sleepTimerActive },
            )
        }
    }
}

@Composable
private fun VintageBottomBarItem(
    icon: ImageVector,
    description: String,
    contentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    label: String? = null,
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier =
            modifier
                .clip(CircleShape)
                .tvFocusHighlight(CircleShape)
                .semantics { contentDescription = description }
                .clickable(role = Role.Button, onClick = onClick)
                .padding(horizontal = 12.dp, vertical = 12.dp),
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = contentColor, modifier = Modifier.size(26.dp))
        if (label != null) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = label, style = MaterialTheme.typography.labelMedium, color = contentColor, maxLines = 1)
        }
    }
}

@Suppress("UNUSED_PARAMETER")
@Composable
fun VintageAudioVideoModeSwitcher(
    songDescription: String,
    videoDescription: String,
    isVideoActive: Boolean,
    isResolving: Boolean,
    contentColor: Color,
    onSongClick: () -> Unit,
    onVideoClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    // One glass pill with the chosen side raised as a lighter glass pill inside it.
    Row(
        modifier =
            modifier
                .width(176.dp)
                .height(44.dp)
                .zentifyGlassButton(CircleShape, contentColor, bodyAlpha = 0.14f)
                .padding(3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        VintageAudioVideoModeItem(
            selected = !isVideoActive,
            enabled = !isResolving,
            label = songDescription,
            showProgress = isResolving && isVideoActive,
            contentColor = contentColor,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            onClick = onSongClick,
        )
        VintageAudioVideoModeItem(
            selected = isVideoActive,
            enabled = !isResolving,
            label = videoDescription,
            showProgress = isResolving && !isVideoActive,
            contentColor = contentColor,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            onClick = onVideoClick,
        )
    }
}

@Composable
private fun VintageAudioVideoModeItem(
    selected: Boolean,
    enabled: Boolean,
    label: String,
    showProgress: Boolean,
    contentColor: Color,
    modifier: Modifier,
    onClick: () -> Unit,
) {
    val shape = CircleShape
    val textColor = if (selected) contentColor else contentColor.copy(alpha = 0.6f)
    Box(
        modifier =
            modifier
                .then(if (selected) Modifier.zentifyGlassButton(shape, contentColor, bodyAlpha = 0.24f) else Modifier)
                .clip(shape)
                .tvFocusHighlight(shape, color = contentColor)
                .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (showProgress) {
            LoadingIndicator(modifier = Modifier.size(20.dp), color = textColor)
        } else {
            Text(text = label, style = MaterialTheme.typography.titleSmall, color = textColor, maxLines = 1)
        }
    }
}
