/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.metrolist.shared.generated.resources.Res
import com.metrolist.shared.generated.resources.zentify_rounded_bold
import com.metrolist.shared.generated.resources.zentify_rounded_extrabold
import com.metrolist.shared.generated.resources.zentify_rounded_regular
import com.metrolist.shared.generated.resources.zentify_rounded_semibold
import org.jetbrains.compose.resources.Font

/** Zentify's typeface: Nunito (SIL OFL), a soft rounded sans-serif. Characters it lacks fall back to the system font. */
@Composable
fun zentifyRoundedFontFamily(): FontFamily =
    FontFamily(
        Font(Res.font.zentify_rounded_regular, FontWeight.Normal),
        Font(Res.font.zentify_rounded_semibold, FontWeight.Medium),
        Font(Res.font.zentify_rounded_semibold, FontWeight.SemiBold),
        Font(Res.font.zentify_rounded_bold, FontWeight.Bold),
        Font(Res.font.zentify_rounded_extrabold, FontWeight.ExtraBold),
    )
