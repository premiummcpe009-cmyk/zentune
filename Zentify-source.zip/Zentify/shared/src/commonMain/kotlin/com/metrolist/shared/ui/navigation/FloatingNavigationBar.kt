@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.metrolist.shared.ui.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ShortNavigationBarDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.lerp
import com.metrolist.shared.ui.theme.ZentifyGlassParams
import com.metrolist.shared.ui.theme.zentifyGlassBackdrop
import com.metrolist.shared.ui.theme.zentifyGlassRim
import com.metrolist.shared.ui.theme.zentifyGlassTint
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

val LocalFloatingNavBar = compositionLocalOf { false }

private val FloatingBarHeight = 68.dp

@Composable
internal fun <T> FloatingNavigation(
    items: List<AdaptiveNavigationItem<T>>,
    selectedKey: T?,
    onSelect: (T) -> Unit,
    navigationVisible: Boolean,
    separateKey: T?,
    itemModifier: @Composable (T) -> Modifier,
    onBarHeightChanged: (Dp) -> Unit,
    modifier: Modifier = Modifier,
) {
    val density = LocalDensity.current
    AnimatedVisibility(
        visible = navigationVisible,
        modifier = modifier,
        enter =
            expandVertically(
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 700f),
                expandFrom = Alignment.Bottom,
            ),
        exit =
            shrinkVertically(
                animationSpec = spring(dampingRatio = 0.9f, stiffness = 700f),
                shrinkTowards = Alignment.Bottom,
            ),
    ) {
        FloatingNavigationBar(
            items = items,
            selectedKey = selectedKey,
            onSelect = onSelect,
            separateKey = separateKey,
            itemModifier = itemModifier,
            modifier =
                Modifier.onSizeChanged { size ->
                    onBarHeightChanged(with(density) { size.height.toDp() })
                },
        )
    }
}

/**
 * Zentify's bottom bar: one frosted-glass pill with every tab (icon above label) and a glass lens that
 * marks the selected tab. Press and hold anywhere on the bar and the whole bar swells while the lens grows
 * past its edges, magnifies and bends the picture behind it; slide to another tab and let go to switch.
 * A plain tap works too. [separateKey] is kept for API compatibility and ignored.
 */
@Composable
private fun <T> FloatingNavigationBar(
    items: List<AdaptiveNavigationItem<T>>,
    selectedKey: T?,
    onSelect: (T) -> Unit,
    separateKey: T?,
    itemModifier: @Composable (T) -> Modifier,
    modifier: Modifier = Modifier,
) {
    val count = items.size
    if (count == 0) return

    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val glassTint = zentifyGlassTint()
    val glassRim = zentifyGlassRim()
    val onSurface = MaterialTheme.colorScheme.onSurface
    val idleColor = onSurface.copy(alpha = 0.72f)

    val selectedIndex = items.indexOfFirst { it.key == selectedKey }.coerceAtLeast(0)
    val latestSelected by rememberUpdatedState(selectedIndex)
    val latestItems by rememberUpdatedState(items)
    val latestOnSelect by rememberUpdatedState(onSelect)

    val lensSpring = remember { spring<Float>(dampingRatio = 0.72f, stiffness = 380f) }
    val lensIndex = remember { Animatable(selectedIndex.toFloat()) }
    var pressing by remember { mutableStateOf(false) }
    val press by animateFloatAsState(
        targetValue = if (pressing) 1f else 0f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = 380f),
        label = "navLensPress",
    )
    var barWidthPx by remember { mutableIntStateOf(0) }

    // Follow the selection when it changes from outside (back press, deep link, ...).
    LaunchedEffect(selectedIndex) {
        if (!pressing) lensIndex.animateTo(selectedIndex.toFloat(), lensSpring)
    }
    // After a gesture, settle on whatever is really selected (a suppressed tap leaves it unchanged).
    LaunchedEffect(pressing) {
        if (!pressing) {
            delay(300)
            lensIndex.animateTo(latestSelected.toFloat(), lensSpring)
        }
    }

    Box(
        modifier =
            modifier
                .fillMaxWidth()
                .windowInsetsPadding(ShortNavigationBarDefaults.windowInsets)
                .padding(horizontal = 20.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Box(
            modifier =
                Modifier
                    .widthIn(max = 440.dp)
                    .fillMaxWidth()
                    .height(FloatingBarHeight)
                    .graphicsLayer {
                        val swell = 1f + 0.025f * press
                        scaleX = swell
                        scaleY = swell
                    }.onSizeChanged { barWidthPx = it.width },
        ) {
            // 1. The frosted pill. It clips to its own shape; the lens below does not.
            Surface(
                modifier = Modifier.fillMaxSize(),
                shape = CircleShape,
                color = Color.Transparent,
                border = BorderStroke(1.dp, glassRim),
            ) {
                Box(Modifier.fillMaxSize().zentifyGlassBackdrop(CircleShape, glassTint))
            }

            // 2. The lens: clearer glass that grows beyond the bar while pressed.
            if (barWidthPx > 0) {
                val slotPx = barWidthPx.toFloat() / count
                val slotDp = with(density) { slotPx.toDp() }
                val lensWidth = slotDp - 12.dp + 34.dp * press
                val lensHeight = lerp(54.dp, FloatingBarHeight + 14.dp, press)
                val lensWidthPx = with(density) { lensWidth.toPx() }
                Box(
                    modifier =
                        Modifier
                            .align(Alignment.CenterStart)
                            .offset {
                                IntOffset((lensIndex.value * slotPx + slotPx / 2f - lensWidthPx / 2f).roundToInt(), 0)
                            }.requiredSize(lensWidth, lensHeight)
                            .zentifyGlassBackdrop(
                                shape = CircleShape,
                                tint = onSurface.copy(alpha = 0.12f - 0.06f * press),
                                params =
                                    ZentifyGlassParams(
                                        blur = lerp(6.dp, 2.dp, press),
                                        bezel = lerp(14.dp, 26.dp, press),
                                        strength = lerp(8.dp, 26.dp, press),
                                        magnify = 1f + 0.22f * press,
                                        highlight = 0.3f + 0.35f * press,
                                    ),
                            ).border(1.dp, glassRim, CircleShape),
                )
            }

            // 3. Icons and labels on top, plus the press / slide gesture for the whole bar.
            Row(
                modifier =
                    Modifier
                        .fillMaxSize()
                        .pointerInput(count) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                val slot = size.width.toFloat() / count
                                if (slot <= 0f) return@awaitEachGesture
                                fun indexAt(x: Float): Float = (x / slot - 0.5f).coerceIn(0f, (count - 1).toFloat())

                                pressing = true
                                var target = indexAt(down.position.x)
                                scope.launch { lensIndex.animateTo(target, lensSpring) }
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!change.pressed) break
                                    target = indexAt(change.position.x)
                                    scope.launch { lensIndex.snapTo(target) }
                                    change.consume()
                                }
                                pressing = false
                                val chosen = target.roundToInt().coerceIn(0, count - 1)
                                scope.launch { lensIndex.animateTo(chosen.toFloat(), lensSpring) }
                                latestItems.getOrNull(chosen)?.let { latestOnSelect(it.key) }
                            }
                        },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                items.forEach { item ->
                    val selected = item.key == selectedKey
                    val tint by animateColorAsState(
                        targetValue = if (selected) onSurface else idleColor,
                        label = "navItemTint",
                    )
                    Column(
                        modifier =
                            Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(itemModifier(item.key))
                                .semantics(mergeDescendants = true) {
                                    role = Role.Tab
                                    this.selected = selected
                                    onClick(label = item.label) {
                                        latestOnSelect(item.key)
                                        true
                                    }
                                },
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            imageVector = if (selected) item.selectedIcon else item.icon,
                            contentDescription = null,
                            tint = tint,
                            modifier = Modifier.size(24.dp),
                        )
                        Text(
                            text = item.label,
                            color = tint,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }
            }
        }
    }
}
