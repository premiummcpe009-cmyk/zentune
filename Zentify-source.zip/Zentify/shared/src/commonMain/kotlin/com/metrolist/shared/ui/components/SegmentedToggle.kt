package com.metrolist.shared.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.ToggleButton
import androidx.compose.material3.ToggleButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.metrolist.shared.ui.theme.zentifyGlassButton

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun SegmentedToggle(
    selectedIndex: Int,
    labels: List<String>,
    modifier: Modifier = Modifier,
    onSelected: (Int) -> Unit,
) {
    require(labels.size >= 2) { "SegmentedToggle requires at least 2 labels" }

    val colorScheme = MaterialTheme.colorScheme
    val toggleColors =
        ToggleButtonDefaults.colors(
            containerColor = Color.Transparent,
            contentColor = colorScheme.onSurfaceVariant,
            checkedContainerColor = Color.Transparent,
            checkedContentColor = colorScheme.onSurface,
        )

    Box(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.Center,
    ) {
        // One glass pill holds the segments; the selected segment is a lighter glass pill inside it.
        Row(
            modifier =
                Modifier
                    .height(52.dp)
                    .zentifyGlassButton(CircleShape, colorScheme.surfaceContainerHigh, bodyAlpha = 0.6f)
                    .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            labels.forEachIndexed { index, label ->
                val selected = selectedIndex == index
                val shapes =
                    ButtonGroupDefaults.connectedLeadingButtonShapes().copy(
                        shape = CircleShape,
                        pressedShape = CircleShape,
                        checkedShape = CircleShape,
                    )
                ToggleButton(
                    checked = selected,
                    onCheckedChange = { onSelected(index) },
                    modifier =
                        Modifier
                            .fillMaxHeight()
                            .then(
                                if (selected) {
                                    Modifier.zentifyGlassButton(CircleShape, colorScheme.secondaryContainer, bodyAlpha = 0.9f)
                                } else {
                                    Modifier
                                },
                            ),
                    shapes = shapes,
                    colors = toggleColors,
                ) {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.titleMedium,
                    )
                }
            }
        }
    }
}
