/**
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.metrolist.shared.generated.resources.Res
import com.metrolist.shared.generated.resources.loading
import org.jetbrains.compose.resources.stringResource

// These keep their old names so every screen picks up the iOS look; the Material containers are gone.

@Composable
fun ContainedLoadingIndicator(
    modifier: Modifier = Modifier,
    containerColor: Color = Color.Unspecified,
    indicatorColor: Color = LocalContentColor.current,
    label: String = stringResource(Res.string.loading),
) {
    ZentifySpinner(
        modifier =
            modifier
                .semantics {
                    contentDescription = label
                    liveRegion = LiveRegionMode.Polite
                }.size(32.dp),
        color = indicatorColor,
    )
}

@Composable
fun ContainedLoadingIndicator(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.Unspecified,
    indicatorColor: Color = LocalContentColor.current,
    label: String = stringResource(Res.string.loading),
) {
    ZentifyProgressRing(
        progress = progress,
        modifier =
            modifier
                .semantics {
                    contentDescription = label
                    liveRegion = LiveRegionMode.Polite
                }.size(32.dp),
        color = indicatorColor,
        trackColor = indicatorColor.copy(alpha = 0.2f),
    )
}

@Composable
fun LoadingScreen(
    modifier: Modifier = Modifier,
    label: String = stringResource(Res.string.loading),
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.Center,
    ) {
        ContainedLoadingIndicator(label = label)
    }
}

@Composable
fun WavyCircularProgressIndicator(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.primary,
    trackColor: Color = MaterialTheme.colorScheme.surfaceVariant,
    animate: Boolean = true,
) {
    ZentifyProgressRing(progress = progress, modifier = modifier, color = color, trackColor = trackColor)
}
