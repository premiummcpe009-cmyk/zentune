/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Zentify is dark-first: neon accents only read as neon on a deep navy base. */
const val ZentifyForceDark = true

object ZentifyColors {
    val Void = Color(0xFF03040A)
    val Ink = Color(0xFF080A12)
    val ElectricBlue = Color(0xFF3D7BFF)
    val NeonCyan = Color(0xFF00E5FF)
    val NeonViolet = Color(0xFFB36BFF)
    val TextPrimary = Color(0xFFEAF2FF)
    val TextMuted = Color(0xFF9AA8C7)
}

val ZentifyDarkColorScheme: ColorScheme =
    darkColorScheme(
        primary = ZentifyColors.NeonCyan,
        onPrimary = Color(0xFF00131A),
        primaryContainer = Color(0xFF06262D),
        onPrimaryContainer = Color(0xFF8CF2FF),
        inversePrimary = Color(0xFF0077A8),
        secondary = Color(0xFF6D9BFF),
        onSecondary = Color(0xFF001A4D),
        secondaryContainer = Color(0xFF0B1B2E),
        onSecondaryContainer = Color(0xFF7FF0FF),
        tertiary = ZentifyColors.NeonViolet,
        onTertiary = Color(0xFF1E0A5C),
        tertiaryContainer = Color(0xFF241046),
        onTertiaryContainer = Color(0xFFE9D9FF),
        background = ZentifyColors.Void,
        onBackground = ZentifyColors.TextPrimary,
        surface = Color(0xFF05070D),
        onSurface = ZentifyColors.TextPrimary,
        surfaceVariant = Color(0xFF141A2A),
        onSurfaceVariant = ZentifyColors.TextMuted,
        surfaceTint = ZentifyColors.NeonCyan,
        inverseSurface = ZentifyColors.TextPrimary,
        inverseOnSurface = ZentifyColors.Ink,
        error = Color(0xFFFF6B8A),
        onError = Color(0xFF3A0010),
        errorContainer = Color(0xFF5C1226),
        onErrorContainer = Color(0xFFFFD9E0),
        outline = Color(0xFF3F4B6B),
        outlineVariant = Color(0xFF1F2740),
        scrim = Color.Black,
        surfaceDim = ZentifyColors.Void,
        surfaceBright = Color(0xFF1A2033),
        surfaceContainerLowest = Color(0xFF020309),
        surfaceContainerLow = Color(0xFF080A12),
        surfaceContainer = Color(0xFF0C0F19),
        surfaceContainerHigh = Color(0xFF121624),
        surfaceContainerHighest = Color(0xFF181D2F),
    )

object ZentifyGlass {
    /** Specular rim: bright top-left edge fading through cyan and blue into a violet bottom-right. */
    val BorderBrush: Brush =
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.45f),
                ZentifyColors.NeonCyan.copy(alpha = 0.25f),
                ZentifyColors.ElectricBlue.copy(alpha = 0.05f),
                ZentifyColors.NeonViolet.copy(alpha = 0.30f),
            ),
        )

    val FillBrush: Brush =
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.05f)),
        )

    /** Smoked-glass body for floating bars: dark enough for legibility, light enough to see content through. */
    val SmokedFill = Color(0xCC070A14)

    /** Mini player body: nearly opaque so the sheet transition stays clean, with a hint of depth. */
    val MiniPlayerFill = Color(0xE6080B14)

    /** Frosted chip body; selected chips use [ChipSelectedFill]. */
    val ChipFill = Color.White.copy(alpha = 0.07f)
    val ChipSelectedFill = ZentifyColors.NeonCyan.copy(alpha = 0.18f)
}

/**
 * Soft neon light pools drawn over the whole app with the Screen blend mode, so they brighten dark
 * areas and barely touch bright artwork. Three radial gradients, no blur, no offscreen layer.
 */
fun Modifier.zentifyAmbientLight(): Modifier =
    drawWithContent {
        drawContent()
        val reach = size.maxDimension
        drawRect(
            brush =
                Brush.radialGradient(
                    listOf(ZentifyColors.ElectricBlue.copy(alpha = 0.20f), Color.Transparent),
                    center = Offset(size.width * 0.10f, size.height * 0.02f),
                    radius = reach * 0.55f,
                ),
            blendMode = BlendMode.Screen,
        )
        drawRect(
            brush =
                Brush.radialGradient(
                    listOf(ZentifyColors.NeonCyan.copy(alpha = 0.10f), Color.Transparent),
                    center = Offset(size.width * 1.0f, size.height * 0.40f),
                    radius = reach * 0.45f,
                ),
            blendMode = BlendMode.Screen,
        )
        drawRect(
            brush =
                Brush.radialGradient(
                    listOf(ZentifyColors.NeonViolet.copy(alpha = 0.16f), Color.Transparent),
                    center = Offset(size.width * 0.25f, size.height * 1.0f),
                    radius = reach * 0.55f,
                ),
            blendMode = BlendMode.Screen,
        )
    }

/**
 * Frosted-glass panel: translucent fill, specular gradient rim and a soft neon glow.
 * It tints what is behind it but does not blur it; put it over [ZentifyBackdrop] or blurred artwork.
 */
fun Modifier.zentifyGlass(
    shape: Shape = RoundedCornerShape(24.dp),
    glow: Color = ZentifyColors.NeonCyan,
): Modifier =
    this
        .shadow(
            elevation = 14.dp,
            shape = shape,
            ambientColor = glow.copy(alpha = 0.35f),
            spotColor = glow.copy(alpha = 0.35f),
        ).clip(shape)
        .background(ZentifyGlass.FillBrush)
        .border(1.dp, ZentifyGlass.BorderBrush, shape)

/** Deep navy base with three soft neon light pools, so glass panels have something to catch. */
@Composable
fun ZentifyBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier =
            modifier
                .background(ZentifyColors.Void)
                .drawBehind {
                    val reach = size.maxDimension
                    drawRect(
                        Brush.radialGradient(
                            listOf(ZentifyColors.ElectricBlue.copy(alpha = 0.35f), Color.Transparent),
                            center = Offset(size.width * 0.15f, size.height * 0.05f),
                            radius = reach * 0.6f,
                        ),
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(ZentifyColors.NeonCyan.copy(alpha = 0.18f), Color.Transparent),
                            center = Offset(size.width * 0.95f, size.height * 0.35f),
                            radius = reach * 0.5f,
                        ),
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(ZentifyColors.NeonViolet.copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(size.width * 0.3f, size.height * 0.95f),
                            radius = reach * 0.55f,
                        ),
                    )
                },
        content = content,
    )
}
