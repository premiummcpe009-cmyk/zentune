/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.metrolist.shared.ui.utils.supportsNativeBlur

/** Zentify is strictly monochrome: black, white and the greys between them. */
val ZentifyDarkColorScheme: ColorScheme =
    darkColorScheme(
        primary = Color(0xFFFFFFFF),
        onPrimary = Color(0xFF000000),
        primaryContainer = Color(0xFF2B2B2B),
        onPrimaryContainer = Color(0xFFF5F5F5),
        inversePrimary = Color(0xFF1A1A1A),
        secondary = Color(0xFFD0D0D0),
        onSecondary = Color(0xFF111111),
        secondaryContainer = Color(0xFF2E2E2E),
        onSecondaryContainer = Color(0xFFEDEDED),
        tertiary = Color(0xFFA6A6A6),
        onTertiary = Color(0xFF111111),
        tertiaryContainer = Color(0xFF1A1A1A),
        onTertiaryContainer = Color(0xFFE0E0E0),
        background = Color(0xFF050505),
        onBackground = Color(0xFFF2F2F2),
        surface = Color(0xFF0A0A0A),
        onSurface = Color(0xFFF2F2F2),
        surfaceVariant = Color(0xFF1C1C1C),
        onSurfaceVariant = Color(0xFFA8A8A8),
        surfaceTint = Color(0xFFFFFFFF),
        inverseSurface = Color(0xFFF2F2F2),
        inverseOnSurface = Color(0xFF111111),
        error = Color(0xFFFF6B6B),
        onError = Color(0xFF2B0000),
        errorContainer = Color(0xFF4D1A1A),
        onErrorContainer = Color(0xFFFFD9D9),
        outline = Color(0xFF6E6E6E),
        outlineVariant = Color(0xFF2E2E2E),
        scrim = Color(0xFF000000),
        surfaceDim = Color(0xFF050505),
        surfaceBright = Color(0xFF2A2A2A),
        surfaceContainerLowest = Color(0xFF000000),
        surfaceContainerLow = Color(0xFF0E0E0E),
        surfaceContainer = Color(0xFF141414),
        surfaceContainerHigh = Color(0xFF1B1B1B),
        surfaceContainerHighest = Color(0xFF232323),
    )

val ZentifyLightColorScheme: ColorScheme =
    lightColorScheme(
        primary = Color(0xFF0A0A0A),
        onPrimary = Color(0xFFFFFFFF),
        primaryContainer = Color(0xFFE4E4E4),
        onPrimaryContainer = Color(0xFF0A0A0A),
        inversePrimary = Color(0xFFFFFFFF),
        secondary = Color(0xFF3A3A3A),
        onSecondary = Color(0xFFFFFFFF),
        secondaryContainer = Color(0xFFDDDDDD),
        onSecondaryContainer = Color(0xFF111111),
        tertiary = Color(0xFF5C5C5C),
        onTertiary = Color(0xFFFFFFFF),
        tertiaryContainer = Color(0xFFEAEAEA),
        onTertiaryContainer = Color(0xFF1A1A1A),
        background = Color(0xFFF5F5F5),
        onBackground = Color(0xFF0A0A0A),
        surface = Color(0xFFF8F8F8),
        onSurface = Color(0xFF0A0A0A),
        surfaceVariant = Color(0xFFE6E6E6),
        onSurfaceVariant = Color(0xFF555555),
        surfaceTint = Color(0xFF000000),
        inverseSurface = Color(0xFF111111),
        inverseOnSurface = Color(0xFFF2F2F2),
        error = Color(0xFFB3261E),
        onError = Color(0xFFFFFFFF),
        errorContainer = Color(0xFFF9DEDC),
        onErrorContainer = Color(0xFF410E0B),
        outline = Color(0xFF8A8A8A),
        outlineVariant = Color(0xFFD0D0D0),
        scrim = Color(0xFF000000),
        surfaceDim = Color(0xFFE2E2E2),
        surfaceBright = Color(0xFFFFFFFF),
        surfaceContainerLowest = Color(0xFFFFFFFF),
        surfaceContainerLow = Color(0xFFF2F2F2),
        surfaceContainer = Color(0xFFECECEC),
        surfaceContainerHigh = Color(0xFFE6E6E6),
        surfaceContainerHighest = Color(0xFFE0E0E0),
    )

@Composable
@ReadOnlyComposable
fun zentifyIsDark(): Boolean = MaterialTheme.colorScheme.surface.luminance() < 0.5f

/** Edge highlight of a glass panel: bright on one corner, fading across, a faint echo on the other. */
fun zentifyRimColors(dark: Boolean): List<Color> =
    if (dark) {
        listOf(Color.White.copy(alpha = 0.45f), Color.White.copy(alpha = 0.06f), Color.White.copy(alpha = 0.22f))
    } else {
        listOf(Color.Black.copy(alpha = 0.22f), Color.Black.copy(alpha = 0.04f), Color.Black.copy(alpha = 0.12f))
    }

@Composable
fun zentifyGlassRim(): Brush = Brush.linearGradient(zentifyRimColors(zentifyIsDark()))

/** Body colour of a glass panel: see-through when real blur is available, mostly opaque when it is not. */
@Composable
@ReadOnlyComposable
fun zentifyGlassTint(): Color =
    MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = if (supportsNativeBlur()) 0.62f else 0.92f)
