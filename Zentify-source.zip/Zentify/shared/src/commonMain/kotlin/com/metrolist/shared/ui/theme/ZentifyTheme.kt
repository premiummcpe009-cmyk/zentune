/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp

/** Zentify is dark-first: neon accents only read as neon on a deep navy base. */
const val ZentifyForceDark = true

object ZentifyColors {
    val Void = Color(0xFF050816)
    val Navy = Color(0xFF0A1230)
    val ElectricBlue = Color(0xFF2F6BFF)
    val NeonCyan = Color(0xFF00E5FF)
    val NeonViolet = Color(0xFF8A5CFF)
    val TextPrimary = Color(0xFFE8F1FF)
    val TextMuted = Color(0xFF9FB3D9)
}

val ZentifyDarkColorScheme: ColorScheme =
    darkColorScheme(
        primary = ZentifyColors.NeonCyan,
        onPrimary = Color(0xFF00131A),
        primaryContainer = Color(0xFF0B3A66),
        onPrimaryContainer = Color(0xFFBDF4FF),
        inversePrimary = Color(0xFF0077A8),
        secondary = Color(0xFF7FA8FF),
        onSecondary = Color(0xFF001A4D),
        secondaryContainer = Color(0xFF16286B),
        onSecondaryContainer = Color(0xFFD6E2FF),
        tertiary = Color(0xFFA98BFF),
        onTertiary = Color(0xFF1E0A5C),
        tertiaryContainer = Color(0xFF352A7A),
        onTertiaryContainer = Color(0xFFE6DEFF),
        background = ZentifyColors.Void,
        onBackground = ZentifyColors.TextPrimary,
        surface = Color(0xFF070B1C),
        onSurface = ZentifyColors.TextPrimary,
        surfaceVariant = Color(0xFF1A2755),
        onSurfaceVariant = ZentifyColors.TextMuted,
        surfaceTint = ZentifyColors.NeonCyan,
        inverseSurface = ZentifyColors.TextPrimary,
        inverseOnSurface = ZentifyColors.Navy,
        error = Color(0xFFFF6B8A),
        onError = Color(0xFF3A0010),
        errorContainer = Color(0xFF5C1226),
        onErrorContainer = Color(0xFFFFD9E0),
        outline = Color(0xFF4A5E94),
        outlineVariant = Color(0xFF26335F),
        scrim = Color.Black,
        surfaceDim = ZentifyColors.Void,
        surfaceBright = Color(0xFF1B2754),
        surfaceContainerLowest = Color(0xFF040612),
        surfaceContainerLow = Color(0xFF0A1128),
        surfaceContainer = Color(0xFF0E1736),
        surfaceContainerHigh = Color(0xFF131E45),
        surfaceContainerHighest = Color(0xFF1A2755),
    )

object ZentifyGlass {
    /** Specular rim: bright top-left edge fading through cyan and blue into a violet bottom-right. */
    val BorderBrush: Brush =
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.45f),
                ZentifyColors.NeonCyan.copy(alpha = 0.25f),
                ZentifyColors.ElectricBlue.copy(alpha = 0.05f),
                ZentifyColors.NeonViolet.copy(alpha = 0.30f),
            ),
        )

    val FillBrush: Brush =
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.05f)),
        )
}

/**
 * Frosted-glass panel: translucent fill, specular gradient rim and a soft neon glow.
 * It tints what is behind it but does not blur it; put it over [ZentifyBackdrop] or blurred artwork.
 */
fun Modifier.zentifyGlass(
    shape: Shape = RoundedCornerShape(24.dp),
    glow: Color = ZentifyColors.NeonCyan,
): Modifier =
    this
        .shadow(
            elevation = 14.dp,
            shape = shape,
            ambientColor = glow.copy(alpha = 0.35f),
            spotColor = glow.copy(alpha = 0.35f),
        ).clip(shape)
        .background(ZentifyGlass.FillBrush)
        .border(1.dp, ZentifyGlass.BorderBrush, shape)

/** Deep navy base with three soft neon light pools, so glass panels have something to catch. */
@Composable
fun ZentifyBackdrop(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    Box(
        modifier =
            modifier
                .background(ZentifyColors.Void)
                .drawBehind {
                    val reach = size.maxDimension
                    drawRect(
                        Brush.radialGradient(
                            listOf(ZentifyColors.ElectricBlue.copy(alpha = 0.35f), Color.Transparent),
                            center = Offset(size.width * 0.15f, size.height * 0.05f),
                            radius = reach * 0.6f,
                        ),
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(ZentifyColors.NeonCyan.copy(alpha = 0.18f), Color.Transparent),
                            center = Offset(size.width * 0.95f, size.height * 0.35f),
                            radius = reach * 0.5f,
                        ),
                    )
                    drawRect(
                        Brush.radialGradient(
                            listOf(ZentifyColors.NeonViolet.copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(size.width * 0.3f, size.height * 0.95f),
                            radius = reach * 0.55f,
                        ),
                    )
                },
        content = content,
    )
}
