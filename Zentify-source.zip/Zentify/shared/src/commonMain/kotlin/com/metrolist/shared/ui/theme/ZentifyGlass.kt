/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.metrolist.shared.ui.utils.supportsNativeBlur

object ZentifyGlass {
    /** Blur strength. Only small areas are blurred (nav pill, mini player), which keeps it cheap on the GPU. */
    val BlurRadius: Dp = 12.dp

    /** Width of the curved-glass rim where the picture bends. */
    val LensBezel: Dp = 20.dp

    /** How far the picture is pulled at the very edge of the rim. */
    val LensStrength: Dp = 14.dp
}

/** How one glass panel looks: frosted bars use the defaults, the draggable nav lens uses a clearer, stronger set. */
@Stable
data class ZentifyGlassParams(
    val blur: Dp = ZentifyGlass.BlurRadius,
    val bezel: Dp = ZentifyGlass.LensBezel,
    val strength: Dp = ZentifyGlass.LensStrength,
    /** 1 = no zoom; above 1 magnifies what is behind the panel. */
    val magnify: Float = 1f,
    /** Brightness of the specular edge light. */
    val highlight: Float = 0.35f,
)

/**
 * A picture of the page content that glass panels blur. The page is recorded once into [layer]
 * while it is drawn normally; each glass panel replays just its own small patch of it.
 * Without hardware blur (below Android 12) nothing is recorded and panels fall back to a tint.
 */
@Stable
class ZentifyBackdrop internal constructor(
    internal val layer: GraphicsLayer,
) {
    /** Window position of the recorded content. Plain field: it is only read while drawing. */
    internal var origin: Offset = Offset.Zero
}

@Composable
fun rememberZentifyBackdrop(): ZentifyBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { ZentifyBackdrop(layer) }
}

val LocalZentifyBackdrop = staticCompositionLocalOf<ZentifyBackdrop?> { null }

/** Marks the page content that glass panels sit on top of. Must not contain the glass panels themselves. */
fun Modifier.zentifyBackdropSource(backdrop: ZentifyBackdrop?): Modifier {
    if (backdrop == null || !supportsNativeBlur()) return this
    return this
        .onGloballyPositioned { backdrop.origin = it.positionInWindow() }
        .drawWithContent {
            backdrop.layer.record(size = IntSize(size.width.toInt(), size.height.toInt())) {
                this@drawWithContent.drawContent()
            }
            drawLayer(backdrop.layer)
        }
}

/**
 * Remembers the blur + liquid-lens effect for one glass panel, rebuilding it only when the panel's
 * size or corner radius changes. [native] lets each platform keep its own reusable shader object.
 */
internal class ZentifyGlassEffectCache {
    private var blur = -1f
    private var width = -1f
    private var height = -1f
    private var corner = -1f
    private var bezel = -1f
    private var strength = -1f
    private var magnify = -1f
    private var highlight = -1f
    private var effect: RenderEffect? = null
    var native: Any? = null

    fun get(
        blurPx: Float,
        widthPx: Float,
        heightPx: Float,
        cornerPx: Float,
        bezelPx: Float,
        strengthPx: Float,
        magnify: Float,
        highlight: Float,
    ): RenderEffect? {
        if (
            blur != blurPx || width != widthPx || height != heightPx || corner != cornerPx ||
            bezel != bezelPx || strength != strengthPx || this.magnify != magnify || this.highlight != highlight
        ) {
            blur = blurPx
            width = widthPx
            height = heightPx
            corner = cornerPx
            bezel = bezelPx
            strength = strengthPx
            this.magnify = magnify
            this.highlight = highlight
            effect = zentifyGlassRenderEffect(this, blurPx, widthPx, heightPx, cornerPx, bezelPx, strengthPx, magnify, highlight)
        }
        return effect
    }
}

/** Blur everywhere, plus a refracting lens rim where the platform supports shaders (Android 13+). */
internal expect fun zentifyGlassRenderEffect(
    cache: ZentifyGlassEffectCache,
    blurPx: Float,
    widthPx: Float,
    heightPx: Float,
    cornerPx: Float,
    bezelPx: Float,
    strengthPx: Float,
    magnify: Float,
    highlight: Float,
): RenderEffect?

/** Frosted liquid glass for an ordinary composable: blurred backdrop patch plus [tint], clipped to [shape]. */
@Composable
fun Modifier.zentifyGlassBackdrop(
    shape: Shape,
    tint: Color,
    params: ZentifyGlassParams = ZentifyGlassParams(),
): Modifier {
    val backdrop = LocalZentifyBackdrop.current
    val effectLayer = rememberGraphicsLayer()
    val cache = remember { ZentifyGlassEffectCache() }
    val base = MaterialTheme.colorScheme.background
    var origin by remember { mutableStateOf(Offset.Zero) }
    val blurOn = backdrop != null && supportsNativeBlur()
    return this
        .onGloballyPositioned { origin = it.positionInWindow() }
        .clip(shape)
        .drawBehind {
            if (blurOn && backdrop != null) {
                val corner =
                    (shape.createOutline(size, layoutDirection, this) as? Outline.Rounded)
                        ?.roundRect
                        ?.topLeftCornerRadius
                        ?.x ?: 0f
                drawBlurredBackdrop(backdrop, effectLayer, cache, Rect(Offset.Zero, size), origin, base, corner, params, 1f)
            }
            drawRect(tint)
        }
}

/**
 * Draws the blurred patch of [backdrop] that lies under [rect] (in this scope's coordinates).
 * The patch sits on an opaque [baseColor] so the sharp page underneath can never show through,
 * and the effect layer is only as big as [rect], so the blur never touches the rest of the screen.
 */
internal fun DrawScope.drawBlurredBackdrop(
    backdrop: ZentifyBackdrop,
    effectLayer: GraphicsLayer,
    cache: ZentifyGlassEffectCache,
    rect: Rect,
    selfOrigin: Offset,
    baseColor: Color,
    cornerPx: Float,
    params: ZentifyGlassParams,
    alpha: Float,
) {
    if (rect.width < 1f || rect.height < 1f) return
    val layerWidth = rect.width.toInt() + 1
    val layerHeight = rect.height.toInt() + 1
    effectLayer.renderEffect =
        cache.get(
            blurPx = params.blur.toPx(),
            widthPx = layerWidth.toFloat(),
            heightPx = layerHeight.toFloat(),
            cornerPx = cornerPx,
            bezelPx = params.bezel.toPx(),
            strengthPx = params.strength.toPx(),
            magnify = params.magnify,
            highlight = params.highlight,
        )
    effectLayer.clip = true
    effectLayer.alpha = alpha
    effectLayer.record(size = IntSize(layerWidth, layerHeight)) {
        drawRect(baseColor)
        translate(
            left = backdrop.origin.x - selfOrigin.x - rect.left,
            top = backdrop.origin.y - selfOrigin.y - rect.top,
        ) { drawLayer(backdrop.layer) }
    }
    translate(left = rect.left, top = rect.top) { drawLayer(effectLayer) }
}

/** Glass version of the mini player sheet: blurred backdrop, tint and rim inside the sheet outline. */
internal fun DrawScope.drawZentifyGlassSheet(
    backdrop: ZentifyBackdrop,
    effectLayer: GraphicsLayer,
    cache: ZentifyGlassEffectCache,
    outline: Outline,
    rect: Rect,
    selfOrigin: Offset,
    baseColor: Color,
    cornerPx: Float,
    tint: Color,
    rimColors: List<Color>,
    alpha: Float,
) {
    val path = outline.toZentifyPath()
    clipPath(path) {
        drawBlurredBackdrop(backdrop, effectLayer, cache, rect, selfOrigin, baseColor, cornerPx, ZentifyGlassParams(), alpha)
        drawPath(path, tint, alpha = alpha)
    }
    val rim = Brush.linearGradient(rimColors, start = rect.topLeft, end = rect.bottomRight)
    drawPath(path, rim, alpha = alpha, style = Stroke(width = 1.dp.toPx()))
}

private fun Outline.toZentifyPath(): Path =
    when (this) {
        is Outline.Rectangle -> Path().apply { addRect(rect) }
        is Outline.Rounded -> Path().apply { addRoundRect(roundRect) }
        is Outline.Generic -> path
    }
