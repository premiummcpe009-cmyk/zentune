/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.metrolist.shared.ui.utils.supportsNativeBlur

object ZentifyGlass {
    /** Blur strength. Small areas only (nav pill, mini player), so this stays cheap on the GPU. */
    val BlurRadius: Dp = 24.dp
}

/**
 * A picture of the page content that glass panels blur. The page is recorded once into [layer]
 * while it is drawn normally; each glass panel replays just its own small patch of it, blurred.
 * Without hardware blur (below Android 12) nothing is recorded and panels fall back to a tint.
 */
@Stable
class ZentifyBackdrop internal constructor(
    internal val layer: GraphicsLayer,
) {
    /** Window position of the recorded content. Plain field: it is only read while drawing. */
    internal var origin: Offset = Offset.Zero
}

@Composable
fun rememberZentifyBackdrop(): ZentifyBackdrop {
    val layer = rememberGraphicsLayer()
    return remember(layer) { ZentifyBackdrop(layer) }
}

val LocalZentifyBackdrop = staticCompositionLocalOf<ZentifyBackdrop?> { null }

/** Marks the page content that glass panels sit on top of. Must not contain the glass panels themselves. */
fun Modifier.zentifyBackdropSource(backdrop: ZentifyBackdrop?): Modifier {
    if (backdrop == null || !supportsNativeBlur()) return this
    return this
        .onGloballyPositioned { backdrop.origin = it.positionInWindow() }
        .drawWithContent {
            backdrop.layer.record(size = IntSize(size.width.toInt(), size.height.toInt())) {
                this@drawWithContent.drawContent()
            }
            drawLayer(backdrop.layer)
        }
}

/** Frosted glass for an ordinary composable: blurred backdrop patch plus [tint], clipped to [shape]. */
@Composable
fun Modifier.zentifyGlassBackdrop(
    shape: Shape,
    tint: Color,
): Modifier {
    val backdrop = LocalZentifyBackdrop.current
    val effectLayer = rememberGraphicsLayer()
    val blurPx = with(LocalDensity.current) { ZentifyGlass.BlurRadius.toPx() }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val blurOn = backdrop != null && supportsNativeBlur()
    return this
        .onGloballyPositioned { origin = it.positionInWindow() }
        .clip(shape)
        .drawBehind {
            if (blurOn && backdrop != null) {
                drawBlurredBackdrop(backdrop, effectLayer, Rect(Offset.Zero, size), origin, blurPx, 1f)
            }
            drawRect(tint)
        }
}

/**
 * Draws the blurred patch of [backdrop] that lies under [rect] (in this scope's coordinates).
 * The effect layer is only as big as [rect], so the blur never touches the rest of the screen.
 */
internal fun DrawScope.drawBlurredBackdrop(
    backdrop: ZentifyBackdrop,
    effectLayer: GraphicsLayer,
    rect: Rect,
    selfOrigin: Offset,
    blurPx: Float,
    alpha: Float,
) {
    if (rect.width < 1f || rect.height < 1f) return
    effectLayer.renderEffect = BlurEffect(blurPx, blurPx, TileMode.Clamp)
    effectLayer.clip = true
    effectLayer.alpha = alpha
    effectLayer.record(size = IntSize(rect.width.toInt() + 1, rect.height.toInt() + 1)) {
        translate(
            left = backdrop.origin.x - selfOrigin.x - rect.left,
            top = backdrop.origin.y - selfOrigin.y - rect.top,
        ) { drawLayer(backdrop.layer) }
    }
    translate(left = rect.left, top = rect.top) { drawLayer(effectLayer) }
}

/** Glass version of the mini player sheet: blurred backdrop, tint and rim inside the sheet outline. */
internal fun DrawScope.drawZentifyGlassSheet(
    backdrop: ZentifyBackdrop,
    effectLayer: GraphicsLayer,
    outline: Outline,
    rect: Rect,
    selfOrigin: Offset,
    tint: Color,
    rimColors: List<Color>,
    alpha: Float,
) {
    val path = outline.toZentifyPath()
    clipPath(path) {
        drawBlurredBackdrop(backdrop, effectLayer, rect, selfOrigin, ZentifyGlass.BlurRadius.toPx(), alpha)
        drawPath(path, tint, alpha = alpha)
    }
    val rim = Brush.linearGradient(rimColors, start = rect.topLeft, end = rect.bottomRight)
    drawPath(path, rim, alpha = alpha, style = Stroke(width = 1.dp.toPx()))
}

private fun Outline.toZentifyPath(): Path =
    when (this) {
        is Outline.Rectangle -> Path().apply { addRect(rect) }
        is Outline.Rounded -> Path().apply { addRoundRect(roundRect) }
        is Outline.Generic -> path
    }
