/*
 * Metrolist Project (C) 2026
 * Licensed under GPL-3.0 | See git history for contributors
 */

package com.metrolist.shared.ui.theme

import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.RenderEffect
import androidx.compose.ui.graphics.TileMode

internal actual fun zentifyGlassRenderEffect(
    cache: ZentifyGlassEffectCache,
    blurPx: Float,
    widthPx: Float,
    heightPx: Float,
    cornerPx: Float,
    bezelPx: Float,
    strengthPx: Float,
    magnify: Float,
    highlight: Float,
): RenderEffect? = BlurEffect(blurPx, blurPx, TileMode.Clamp)
